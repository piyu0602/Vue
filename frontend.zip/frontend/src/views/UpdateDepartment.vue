<template>
    <main>
        <Navbar/>
        <div class="my-5">
            <div class="mx-auto w-25 " style="max-width:100%;">
              <h2 class="text-center mb-3">Update Department</h2>
              <form @submit.prevent="updateDepartment">
                <!--name-->
                <div class="row">
                  <div class="col-md-12 form-group mb-3">
                    <label for="dept_name" class="form-label">Name</label>
                    <input id="dept_name"  type="text" name="dept_name" class="form-control" placeholder="Name" required v-model="department.dept_name">
                  </div>
                </div>
          
                
               
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input class="btn btn-primary w-100" type="submit" value="Submit">
                  </div>
                </div>
      
                <div>
                  
                </div>
              </form>
        
            </div>
          </div>

    </main>
</template>


<script>
import Navbar from '../components/Navbar.vue';

export default {
    name: 'UpdateDepartment',
    components: {
        Navbar
    },

    data(){
        return {
            department: {
                id: '',
                dept_name: '',
                active: ''
            }
        }
    },

    beforeMount(){
        this.getDepartments();
    },

    methods: {
        getDepartments(){
            fetch(`http://localhost:8080/department/${this.$route.params.id}`)
            .then(res => res.json())
            .then(data => {
                this.department = data;
                console.log(this.department);
            })

        },
        updateDepartment(){
            fetch(`http://localhost:8080/department`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.department)
            })
            .then(data => {
                console.log(data);
                this.$router.push('/');
            })
        }
    }
}

</script>