<template>
    <main>
        <Navbar />
        <div class="my-5">
            <div class="mx-auto w-25 " style="max-width:100%;">
              <h2 class="text-center mb-3">Add Department</h2>
              <form @submit.prevent="addDepartment">
                <!--name-->
                <div class="row">
                  <div class="col-md-12 form-group mb-3">
                    <label for="dept_name" class="form-label">Department Name: </label>
                    <input id="dept_name"  type="text" name="name" class="form-control" placeholder="Name" required v-model="department.dept_name">
                  </div>
                </div>

      
                <!--Gender-->
                <label for="active" class="form-label">Is Active</label>
                <div class="form-check">
                  <input class="form-check-input"   type="radio" name="active" id="Yes" value="Yes" v-model="department.active">
                  <label class="form-check-label" for="Yes">Yes</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio"   name="active" id="No" value="No" v-model="department.active">
                  <label class="form-check-label" for="No">No</label>
                </div>
               
                
               
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input class="btn btn-primary w-100" type="submit" value="Submit">
                  </div>
                </div>
      
                <div>
                  
                </div>
              </form>
        
            </div>
          </div>
    </main>
</template>


<script>
import Navbar from '../components/Navbar.vue';

    export default {
        name: 'AddDepartment',
        components: {
            Navbar
        },

        data() {
            return {
                department : {
                    dept_name: '',
                    active: ''
                }
            }
        },

        methods: {
            addDepartment(){
                fetch('http://localhost:8080/add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.department)
                })
                .then(data => {
                    console.log(data)
                    this.$router.push("/");
                })

            }
        },
            
    }


</script>