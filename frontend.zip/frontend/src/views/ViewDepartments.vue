<template>
    <main>
        <Navbar />

        <!-- Table-->
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center">View Department</h1>
                    <!--Add button -->
                    <a href="/add" class="btn btn-primary">Add Department</a>
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Active</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="department in departments" :key="department.id">
                            <th scope="row">{{department.id}}</th>
                            <td>{{department.dept_name}}</td>
                            <td>{{department.active}}</td>
                            <td>
                              <a class="btn btn-primary" :href="`/edit/${department.id}`">Edit</a>
                              <button class="btn btn-danger mx-2" @click="deleteDepartment(department.id)">Delete</button>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
        
    </main>
</template>


<script>
import Navbar from '../components/Navbar.vue'

    export default {
        name: 'ViewDepartments',
        components: {
            Navbar
        },
        data() {
            return {
                departments: []
            }
        },

        beforeMount(){
            this.getDepartments()
        },

        methods: {
            getDepartments(){
                fetch('http://localhost:8080/departments')
                .then(res => res.json())
                .then(data => {
                    this.departments = data
                    console.log(data)
                })
            },
            deleteDepartment(id){
                fetch(`http://localhost:8080/department/${id}`, {
                    method: 'DELETE'
                })
                .then(data => {
                    console.log(data)
                    this.getDepartments()
                })
            }
        }

    }

</script>