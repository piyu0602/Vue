import { createRouter, createWebHistory } from 'vue-router'
import ViewDepartments from '../views/ViewDepartments.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: ViewDepartments
    },
    {
      path: '/add',
      name: 'add',
      component: () => import('../views/AddDepartment.vue')
    },
    {
      path: '/edit/:id',
      name: 'edit',
      component: () => import('../views/UpdateDepartment.vue')
    }
  ]
})

export default router
